#!/bin/bash
ip_server3="20.213.250.113"
senha_server3="2565011"
database="/root/usuarios.db"

read uline
    if sshpass -p "$senha_server3" ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no root@$ip_server3 echo "ok" 1>/dev/null 2>/dev/null; then
sshpass -p "$senha_server3" ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no root@$ip_server3 << EOF
		user="$(echo $uline | cut -d' ' -f1)"
		[[ -e /etc/openvpn/openvpn-status.log ]] && ovp="$(cat /etc/openvpn/openvpn-status.log | grep -E ,"$user", | wc -l)" || ovp=0
		[[ "$(grep -wc $user /etc/passwd)" != '0' ]] && {
			s1ssh="$(ps -u $user | grep -c sshd)"
			conex=$(($s1ssh + $ovp))
			tput setaf 3 ; tput bold ; printf '  %-35s%s\n' $user,$conex,; tput sgr0
		}
		EOF
		exit
else
	echo -e "Erro Tente novamente Mais tarde!)"
	exit
fi